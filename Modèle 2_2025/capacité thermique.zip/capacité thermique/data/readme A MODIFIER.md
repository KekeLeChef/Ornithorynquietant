Les fichiers `ne_10m_coastline.shp`, `.shx` et `.dbf` (Natural Earth) décrivent les lignes côtières mondiales à 10m de résolution.  
Ils sont utilisés pour **délimiter les zones terrestres** lors des calculs ou visualisations de **diffusion thermique et de température**.
