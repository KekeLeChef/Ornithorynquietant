Les fichier albedo01.csv ... albedo12.csv correspondent à janvier ... decembre.
Chaque fichier a sur la première ligne l'ensemble des latitudes et sur la première colonne l'ensemble des longitudes.
L'intersection correspond à l'albedo moyen de chaque mois en 2023 de cette coordonnée GPS.
Cette base de données a été créée grâce aux fichiers "construcion_csv.py" et "remplissage_csv.py".